//Dart
//Atividade 01
//Letra J

void main() {

  //Declaração
  double c = 30;

  //Operação
  double f = (c * 9 / 5) + 32;

  //Saída
  print('Graus em Celsius: $c Cº');
  print('Transformação de Celsius para Fahrenheit: $f Fº');
}
