//Dart
//Atividade 01
//Letra G

void main() {

  //Declaração
  double base = 5;
  double altura = 5;

  //Operações
  double area = (5 * 5);
  double dobro = (area * 2);

  //Saída
  print('Valor da base: $base');
  print('Valor da altura: $altura');
  print('-'* 50);
  print('A área do quadrado é: $area');
  print('O dobro da área é: $dobro');
}
