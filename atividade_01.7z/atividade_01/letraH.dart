//Dart
//Atividade 01
//Letra H

void main() {
  
  //Declaração
  double ganho = 50;
  double trabalho = 160;
  double salario = (ganho * trabalho);

  //Saída
  print('Ganho por hora: $ganho Reais');
  print('Trabalho por mês: $trabalho horas');
  print('Meu sálario: $salario Reais por mês');
}