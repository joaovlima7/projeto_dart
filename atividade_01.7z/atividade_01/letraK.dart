//Dart
//Atividade 01
//Letra K

void main() {

  //Declaração
  int numero1 = 5;
  int numero2 = 10;
  double numero3 = 1.5;

  //Operações
  double multiplica = (numero1 * 2 * numero2 / 2);
  double soma = (numero1 * 3 + numero3);
  double elevado = (numero3 * numero3 * numero3);

  //Saída
  print('Dobro do primeiro com metade do segundo: $multiplica');
  print('');
  print('Soma do triplo do primeiro com o terceiro: $soma');
  print('');
  print('Terceiro elevado ao cubo: $elevado');
}