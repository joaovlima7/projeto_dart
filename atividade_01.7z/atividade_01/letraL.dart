//Dart
//Atividade 01
//Letra L

void main() {

  //Declaração
  double altura = 1.70;

  //Operação
  double peso = (72.7 * altura) - 58;

  //Saída
  print('Seu peso ideal é: $peso kg');
}