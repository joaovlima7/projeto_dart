//Dart
//Atividade 01
//Letra I

void main() {

  //Declaração
  double f = 70;

  //Operação
  double c = (5 * (f-32)/9 );

  //Saída
  print('Graus em Fahrenheit: $f Fº');
  print('Transformação de Fahrenheit para celsius é: $c C°');
}