//Dart
//Atividade 01
//Letra E

void main() {
  //Declaração
  double medida = 1;
  double conversao = (medida * 100);
  
  //Saída
  print('Medida em metros: $medida cm');
  print('Medida em centimetros: $conversao cm');
}
