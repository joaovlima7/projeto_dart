//Dart
//Atividade 01
//Letra M

void main() {

  //Declaração
  double altura = 1.70;

  //Operação
  double homem = (72.7 * altura) - 58;
  double mulher = (62.1 * altura) - 44.7;

  //Saída
  print('Sendo Homem, seu peso ideal é: $homem Kg');
  print('sendo mulher, seu peso ideal é: $mulher Kg');
}