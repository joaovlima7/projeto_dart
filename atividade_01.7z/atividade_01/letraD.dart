//Dart
//Atividade 01
//Letra D


import 'dart:io';

void main() {
  //Declaração

  double nota1 = 7;
  double nota2 = 6;
  double nota3 = 8;
  double nota4 = 9;

  print('As notas do aluno é: $nota1, $nota2, $nota3, $nota4');

  double media = (nota1 + nota2 + nota3 + nota4) / 4;

  print('A média do aluno é: $media');
}
