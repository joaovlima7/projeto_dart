//Dart
//Atividade 01
//Letra N

void main() {

  //Declaração
  double multa = 4.00;
  double peso = 50;

  //Operação
  double calculo = (multa * peso);

  //Saída
  print('Você tera que pagar o valor de: $calculo Reais');
}