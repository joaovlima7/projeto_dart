//Dart
//Atividade 01
//Letra F

void main() {

  //Declaração
  double raio = 8;
  const pi = 3.14;

  double area = (pi * raio * raio);

  print('A área do circulo é $area');
}
