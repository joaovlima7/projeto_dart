//Dart
//Atividade 01
//Letra A

//Função principal
void main() {
  //Saída
  print('Alô mundo!');
}