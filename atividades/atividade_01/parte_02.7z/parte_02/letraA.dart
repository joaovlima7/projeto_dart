//Dart
//Atividade 02
//Letra A

import 'dart:io';

void main() {

  //Entrada de dados
  stdout.write('Digite uma mensagem: ');
  String? mensagem = stdin.readLineSync();

  //Saída
  print('Mensagem: $mensagem');
}